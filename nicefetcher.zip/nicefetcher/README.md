# counterparty_rs

Rust and pyo3-based speed-ups for `counterparty-core`.

This is a rust-based python wheel that wraps [rust-bitcoin](https://docs.rs/bitcoin/latest/bitcoin/).

